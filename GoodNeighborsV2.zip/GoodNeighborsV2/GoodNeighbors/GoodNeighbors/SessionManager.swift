//
//  SessionManager.swift
//  Authenticated
//
//  Created by Jaewoo Seo on 3/29/24.
//

import AWSMobileClient
import Amplify
import AmplifyPlugins
import SwiftUI
import Foundation

enum AuthState {
    case signup
    case login
    case confirmCode(username: String)
    case gatherT_users
    case session(user: AuthUser)
}

final class SessionManager: ObservableObject {
    @Published var authState: AuthState = .login
    func getCurrentAuthUser() {
        if let user = Amplify.Auth.getCurrentUser() {
            authState = .session(user: user)
        } else {
            authState = .login
        }
    }
    func showT_view() {
        authState = .gatherT_users
    }
    func showSignUp() {
        authState = .signup
    }
    
    func showLogin() {
        authState = .login
    }
    
    func signUp(username: String, email: String, password: String) {
        let attributes = [AuthUserAttribute(.email, value: email)]
        let options = AuthSignUpRequest.Options(userAttributes: attributes)
        
        _ = Amplify.Auth.signUp(
            username: username,
            password: password,
            options: options
        ) { [weak self] result in
            switch result {
            case .success(let signUpResult):
                print("Sign up result:", SignUpResult.self)
                
                switch signUpResult.nextStep {
                case .done:
                    print("Finished sign up")
                
                case .confirmUser(let details, _):
                    print(details ?? "no details")
                    
                    DispatchQueue.main.async {
                        self?.authState = .confirmCode(username: username)
                    }
                }
                
            case .failure(let error):
                print("Sing up error", error)
            }
            
            
        }
    }
    
    func confirm(username: String, code: String) {
        _ = Amplify.Auth.confirmSignUp(
            for: username,
            confirmationCode: code
        ) { [weak self] result in
            switch result {
            case .success(let confirmResult):
                print(confirmResult)
                if confirmResult.isSignupComplete {
                    DispatchQueue.main.async {
                        self?.showT_view()
                    }
                }
                
            case .failure(let error):
                print("failed to confirm code:", error)
            }
        }
    }
    
    
    
    func login(username: String, password: String) {
        _ = Amplify.Auth.signIn(
            username: username,
            password: password
        ) { [weak self] result in
            switch result {
            case .success(let signInResult):
                print(SignInResult.self)
                if signInResult.isSignedIn {
                    TokenManager.shared.bearerToken{
                        
                        getMedicalData {
                            if let uid = uid {
                                print("UID: \(uid)")
                            } else {
                                print("UID is nil")
                            }

                            if let heartRate = heartRate {
                                print("Heart Rate: \(heartRate)")
                            } else {
                                print("Heart Rate is nil")
                            }

                            if let isMoving = isMoving {
                                print("Is Moving: \(isMoving == 1 ? "Yes" : "No")")
                            } else {
                                print("Is Moving is nil")
                            }

                            if let longitude = longitude {
                                print("Longitude: \(longitude)")
                            } else {
                                print("Longitude is nil")
                            }

                            if let latitude = latitude {
                                print("Latitude: \(latitude)")
                            } else {
                                print("Latitude is nil")
                            }
                        }
                    }
                    DispatchQueue.main.async {
                        self?.getCurrentAuthUser()
                    }
                }
                
            case .failure(let error):
                print("Login error:", error)
            }
        }
    }
    
    func signOut() {
        _ = Amplify.Auth.signOut { [weak self] result in
            switch result {
            case .success:
                DispatchQueue.main.async {
                    self?.getCurrentAuthUser()
                }
            case .failure(let error):
                print("Sign out error:", error)
                
            }
        }
        
    }
}
