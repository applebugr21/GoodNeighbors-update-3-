import Foundation
import Amplify
import AmplifyPlugins

var uid: String?
var heartRate: Int?
var isMoving: Int?
var longitude: String?
var latitude: String?
var healthIndex: Int?
var globalIdToken: String?

func getMedicalData(completion: @escaping () -> Void) {
    print(TokenManager.shared.idToken)
    // Define the URL and JSON data
    let url = URL(string: "https://7r6wansua5.execute-api.us-east-1.amazonaws.com/test/medicalInformation")!
    let json: [String: Any] = [
        "uid": "jseo5"
    ]
    
    // Convert JSON to Data
    guard let jsonData = try? JSONSerialization.data(withJSONObject: json) else {
        print("Failed to serialize JSON")
        return
    }
    
    // Create the request
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    //var idToken: String = ""
    
    
    //idToken = bearerToken { (_ idToken) in
    //    if idToken == "" {
            //error
    //    } else {
            
    //    }
    //}    //print("idToken:", idToken)
    
    //where your Token Goes
    request.setValue("Bearer \(String(describing: TokenManager.shared.idToken))", forHTTPHeaderField: "Authorization")
    request.httpBody = jsonData

    // Perform the request
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            print("Error: \(error)")
            return
        }

        guard let data = data else {
            print("No data received")
            return
        }

        if let response = response as? HTTPURLResponse {
            print("Response status code: \(response.statusCode)")
        }

        if let responseString = String(data: data, encoding: .utf8) {
          //  print("Response data: \(responseString)")
        }

        // Parse the response JSON data
        do {
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                // Access the variables
                if let body = json["body"] as? [String: Any] {
                    healthIndex = body["healthIndex"] as? Int
                    heartRate = body["heartRate"] as? Int
                    isMoving = body["isMoving"] as? Int
                    longitude = body["longitude"] as? String
                    latitude = body["latitude"] as? String
                    uid = body["uid"] as? String
                    completion()
                    print("JSON response: \(json)")
                    
                } else {
                    print("Failed to parse 'body' as dictionary")
                }
            } else {
                print("Failed to parse JSON as dictionary")
            }
        } catch {
            print("Error parsing JSON: \(error)")
        }
    }
    
    

    task.resume()
}








func postTrustedUid(completion: @escaping () -> Void) {
    print(TokenManager.shared.idToken)
    // Define the URL and JSON data
    
    print(GatherViewHolder.shared2.t_uid1)
    print(GatherViewHolder.shared2.t_uid3)
    print(GatherViewHolder.shared2.t_uid5)
    let url = URL(string: "https://7r6wansua5.execute-api.us-east-1.amazonaws.com/test/userInfo/TrustedUid")!
    let json: [String: Any] = [
        "uid": "testMainuser2",
        "t_uid1": GatherViewHolder.shared2.t_uid1,
        "t_uid2": GatherViewHolder.shared2.t_uid2,
        "t_uid3": GatherViewHolder.shared2.t_uid3,
        "t_uid4": GatherViewHolder.shared2.t_uid4,
        "t_uid5": GatherViewHolder.shared2.t_uid5
    ]
    
    // Convert JSON to Data
    guard let jsonData = try? JSONSerialization.data(withJSONObject: json) else {
        print("Failed to serialize JSON")
        return
    }
    
    // Create the request
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    //var idToken: String = ""
    
    
    //where your Token Goes
    request.setValue("Bearer \(String(describing: TokenManager.shared.idToken))", forHTTPHeaderField: "Authorization")
    request.httpBody = jsonData

    // Perform the request
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
    if let error = error {
    print("Error: \(error)")
        return
    }

    guard let data = data else {
        print("No data received")
        return
        }

    if let response = response as? HTTPURLResponse {
        print("Response status code: \(response.statusCode)")
    }

    if String(data: data, encoding: .utf8) != nil {
        //  print("Response data: \(responseString)")
    }
//
    // Parse the response JSON data
    do {
        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
            // Access the variables
            if let body = json["body"] as? [String: Any] {
                healthIndex = body["healthIndex"] as? Int
                heartRate = body["heartRate"] as? Int
                isMoving = body["isMoving"] as? Int
                longitude = body["longitude"] as? String
                latitude = body["latitude"] as? String
                uid = body["uid"] as? String
                completion()
                print("JSON response: \(json)")
                
            } else {
                print("Failed to parse 'body' as dictionary")
            }
        } else {
            print("Failed to parse JSON as dictionary")
        }
    } catch {
        print("Error parsing JSON: \(error)")
}
}
    
    

    task.resume()
}
