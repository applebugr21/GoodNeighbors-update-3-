//
//  AuthenticatedApp.swift
//  Authenticated
//
//  Created by Jaewoo Seo on 3/29/24.
//
import Amplify
import AmplifyPlugins
import SwiftUI
import AWSS3

@main
struct GoodNeighborsApp: App {
    
    @ObservedObject var sessionManager = SessionManager()
    @StateObject var bleSdkManager = PolarBleSdkManager()
    
    init() {
        configureAmplify()
        sessionManager.getCurrentAuthUser()
    }
    
    var body: some Scene {
        WindowGroup {
            switch sessionManager.authState {
            case.login:
                LoginView()
                    .environmentObject(sessionManager)
            
            case .signup:
                SignUpView()
                    .environmentObject(sessionManager)
                
            case .confirmCode(let username):
                ConfirmationView(username: username)
                    .environmentObject(sessionManager)
            
            case .gatherT_users:
                GatherView()
                    .environmentObject(sessionManager)
                
                
            case .session(let user):
                SessionView(user: user)
                    .environmentObject(bleSdkManager)
                    .environmentObject(sessionManager)
            }
        }
    }
    private func configureAmplify() {
        do {
            try Amplify.add(plugin: AWSCognitoAuthPlugin())
            try Amplify.add(plugin: AWSS3StoragePlugin())
            try Amplify.configure()
            print("Amplify configured successfully")
        } catch {
            print("could not initialize Amplify", error)
        }
    }
}
